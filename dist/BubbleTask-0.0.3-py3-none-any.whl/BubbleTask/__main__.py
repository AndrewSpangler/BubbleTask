from .BubbleTask import BubbleApp

if __name__ == "__main__":
    BubbleApp().mainloop()
